<?php
session_start();
require_once '../includes/config.php';
requireAdmin();
$activePage = 'users';
$admin = new Admin();
$success = $error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action = $_POST['action']??'';
    if ($action==='tambah') {
        $r = $admin->tambahUser($_POST['username'],$_POST['password'],$_POST['nama_lengkap'],$_POST['role']);
        $r['success'] ? ($success='User berhasil ditambahkan!') : ($error='Username sudah digunakan.');
    } elseif ($action==='hapus') {
        $admin->hapusUser((int)$_POST['id_user']);
        $success='User berhasil dihapus.';
    }
}
$users = $admin->getAllUsers();
?>
<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><title>Kelola User – <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css"></head>
<body>
<div class="app-layout">
  <?php include '../includes/sidebar.php'; ?>
  <div class="main-content">
    <div class="topbar">
      <div><div class="topbar-title">👥 Kelola User</div></div>
      <button class="btn btn-primary" onclick="document.getElementById('mTambah').classList.add('show')">➕ Tambah User</button>
    </div>
    <div class="content-area">
      <?php if($success): ?><div class="alert alert-success">✅ <?= $success ?></div><?php endif; ?>
      <?php if($error):   ?><div class="alert alert-danger">⚠️ <?= $error ?></div><?php endif; ?>
      <div class="card">
        <div class="card-header"><h3>Daftar User (<?= count($users) ?>)</h3></div>
        <div class="table-responsive">
          <table>
            <thead><tr><th>#</th><th>Username</th><th>Nama Lengkap</th><th>Role</th><th>Terdaftar</th><th>Aksi</th></tr></thead>
            <tbody>
            <?php foreach($users as $i=>$u): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><strong><?= htmlspecialchars($u['username']) ?></strong></td>
              <td><?= htmlspecialchars($u['nama_lengkap']) ?></td>
              <td><span class="badge <?= $u['role']==='admin'?'badge-danger':'badge-info' ?>"><?= ucfirst($u['role']) ?></span></td>
              <td class="text-muted" style="font-size:12px"><?= date('d/m/Y',strtotime($u['created_at'])) ?></td>
              <td>
                <?php if($u['role']!=='admin'): ?>
                <form method="POST" style="display:inline" onsubmit="return confirm('Hapus user ini?')">
                  <input type="hidden" name="action" value="hapus">
                  <input type="hidden" name="id_user" value="<?= $u['id_user'] ?>">
                  <button type="submit" class="btn btn-danger btn-sm">🗑️ Hapus</button>
                </form>
                <?php else: ?><span class="badge badge-secondary">Protected</span><?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="modal-overlay" id="mTambah">
  <div class="modal">
    <div class="modal-header"><h3>➕ Tambah User</h3><button class="modal-close" onclick="document.getElementById('mTambah').classList.remove('show')">×</button></div>
    <form method="POST"><input type="hidden" name="action" value="tambah">
      <div class="modal-body">
        <div class="form-group"><label>Nama Lengkap</label><input type="text" name="nama_lengkap" required></div>
        <div class="form-group"><label>Username</label><input type="text" name="username" required></div>
        <div class="form-group"><label>Password</label><input type="password" name="password" required></div>
        <div class="form-group"><label>Role</label><select name="role"><option value="kasir">Kasir</option><option value="admin">Admin</option></select></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" onclick="document.getElementById('mTambah').classList.remove('show')">Batal</button>
        <button type="submit" class="btn btn-primary">💾 Simpan</button>
      </div>
    </form>
  </div>
</div>
</body></html>
