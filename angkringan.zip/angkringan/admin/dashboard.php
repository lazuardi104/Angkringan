<?php
session_start();
require_once '../includes/config.php';
requireAdmin();
$activePage = 'dashboard';
$stats = (new Admin())->getDashboardStats();
$chartJson = json_encode($stats['chart']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard – <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>
<div class="app-layout">
  <?php include '../includes/sidebar.php'; ?>
  <div class="main-content">
    <div class="topbar">
      <div>
        <div class="topbar-title">📊 Dashboard</div>
        <div class="topbar-subtitle"><?= date('l, d F Y') ?></div>
      </div>
    </div>
    <div class="content-area">

      <!-- STAT CARDS -->
      <div class="stats-grid">
        <div class="stat-card red">
          <div class="stat-icon">💰</div>
          <div>
            <span class="stat-label">Pendapatan Hari Ini</span>
            <span class="stat-value sm"><?= formatRupiah($stats['today']) ?></span>
          </div>
        </div>
        <div class="stat-card orange">
          <div class="stat-icon">📅</div>
          <div>
            <span class="stat-label">Pendapatan Bulan Ini</span>
            <span class="stat-value sm"><?= formatRupiah($stats['month']) ?></span>
          </div>
        </div>
        <div class="stat-card green">
          <div class="stat-icon">🧾</div>
          <div>
            <span class="stat-label">Transaksi Hari Ini</span>
            <span class="stat-value"><?= $stats['txToday'] ?></span>
          </div>
        </div>
        <div class="stat-card blue">
          <div class="stat-icon">🍽️</div>
          <div>
            <span class="stat-label">Menu Aktif</span>
            <span class="stat-value"><?= $stats['menuAktif'] ?></span>
          </div>
        </div>
      </div>

      <!-- CHART + TERLARIS -->
      <div style="display:grid;grid-template-columns:1.6fr 1fr;gap:18px;margin-bottom:20px">
        <div class="card">
          <div class="card-header">
            <h3>📈 Pendapatan 7 Hari Terakhir</h3>
          </div>
          <div class="card-body">
            <div class="chart-wrapper" style="height:220px">
              <canvas id="revenueChart"></canvas>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header"><h3>🔥 Menu Terlaris (30 hari)</h3></div>
          <div style="padding:6px 0">
            <?php if (empty($stats['terlaris'])): ?>
            <div class="empty-state"><span class="eicon">📭</span><p>Belum ada data</p></div>
            <?php else: ?>
            <?php $colors = ['#e63946','#f4a261','#2a9d8f','#4361ee','#7c3aed']; ?>
            <?php foreach ($stats['terlaris'] as $i => $item): ?>
            <div style="display:flex;align-items:center;gap:12px;padding:11px 18px;border-bottom:1px solid #f3f4f6">
              <span style="width:26px;height:26px;background:<?= $colors[$i] ?>;border-radius:50%;color:white;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;flex-shrink:0"><?= $i+1 ?></span>
              <span style="flex:1;font-size:13px;font-weight:700"><?= htmlspecialchars($item['nama_menu']) ?></span>
              <span style="font-size:12px;color:#6b7280;font-weight:600"><?= $item['terjual'] ?>x</span>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- TRANSAKSI HARI INI -->
      <div class="card">
        <div class="card-header">
          <h3>🧾 Transaksi Hari Ini</h3>
          <a href="laporan.php" class="btn btn-outline btn-sm">Lihat Semua →</a>
        </div>
        <div class="table-responsive">
          <?php $orders = (new Admin())->lihatLaporan(); ?>
          <?php if (empty($orders)): ?>
          <div class="empty-state"><span class="eicon">📭</span><p>Belum ada transaksi hari ini</p></div>
          <?php else: ?>
          <table>
            <thead><tr><th>Kode Order</th><th>Kasir</th><th>Tempat</th><th>Total</th><th>Metode</th><th>Pukul</th></tr></thead>
            <tbody>
            <?php foreach (array_slice($orders,0,8) as $o): ?>
            <tr>
              <td><strong><?= htmlspecialchars($o['kode_order']) ?></strong></td>
              <td><?= htmlspecialchars($o['nama_lengkap']) ?></td>
              <td><?= htmlspecialchars($o['nama_tempat'] ?? 'Take Away') ?></td>
              <td><strong class="text-primary"><?= formatRupiah($o['total']) ?></strong></td>
              <td><span class="badge <?= $o['metode_bayar']==='tunai'?'badge-success':($o['metode_bayar']==='qris'?'badge-info':'badge-warning') ?>"><?= strtoupper($o['metode_bayar']??'TUNAI') ?></span></td>
              <td class="text-muted" style="font-size:12px"><?= date('H:i',strtotime($o['tanggal'])) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
          <?php endif; ?>
        </div>
      </div>

    </div>
  </div>
</div>
<script>
(function(){
  const raw = <?= $chartJson ?>;
  const labels = raw.map(r => {
    const d = new Date(r.tgl + 'T00:00:00');
    return d.toLocaleDateString('id-ID', {weekday:'short', day:'numeric', month:'short'});
  });
  const values = raw.map(r => parseInt(r.total) || 0);
  const maxVal = Math.max(...values, 1);

  const ctx = document.getElementById('revenueChart').getContext('2d');

  // gradient fill
  const grad = ctx.createLinearGradient(0, 0, 0, 220);
  grad.addColorStop(0, 'rgba(230,57,70,0.25)');
  grad.addColorStop(1, 'rgba(230,57,70,0.01)');

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Pendapatan',
        data: values,
        backgroundColor: values.map((v,i) => i === values.length-1 ? '#e63946' : 'rgba(230,57,70,0.18)'),
        borderColor: '#e63946',
        borderWidth: 2,
        borderRadius: 7,
        borderSkipped: false,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: ctx => 'Rp ' + ctx.parsed.y.toLocaleString('id-ID')
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: '#f3f4f6' },
          ticks: {
            callback: v => {
              if (v >= 1000000) return 'Rp ' + (v/1000000).toFixed(1) + 'jt';
              if (v >= 1000)    return 'Rp ' + (v/1000).toFixed(0) + 'rb';
              return 'Rp ' + v;
            },
            font: { size: 11 }, color: '#6b7280'
          }
        },
        x: {
          grid: { display: false },
          ticks: { font: { size: 11 }, color: '#6b7280' }
        }
      }
    }
  });
})();
</script>
</body>
</html>
