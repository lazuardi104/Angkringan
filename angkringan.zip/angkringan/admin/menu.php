<?php
session_start();
require_once '../includes/config.php';
requireAdmin();
$activePage = 'menu';
$admin  = new Admin();
$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'tambah') {
        $r = $admin->tambahMenu($_POST['nama_menu'], $_POST['kategori'], (int)$_POST['harga'], (int)$_POST['stok']);
        $r['success'] ? ($success='Menu berhasil ditambahkan!') : ($error=$r['message']);
    } elseif ($action === 'edit') {
        $r = $admin->editMenu((int)$_POST['id_menu'],$_POST['nama_menu'],$_POST['kategori'],(int)$_POST['harga'],(int)$_POST['stok'],(int)($_POST['tersedia']??1));
        $r['success'] ? ($success='Menu berhasil diperbarui!') : ($error=$r['message']);
    } elseif ($action === 'hapus') {
        $r = $admin->hapusMenu((int)$_POST['id_menu']);
        $r['success'] ? ($success='Menu berhasil dihapus!') : ($error=$r['message']);
    }
}

$db = Database::getInstance();
$res = $db->query("SELECT * FROM menu ORDER BY kategori, nama_menu");
$menus = [];
while ($r = $res->fetch_assoc()) $menus[] = $r;
$katList = ['Makanan','Sate','Gorengan','Minuman','Lainnya'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kelola Menu – <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
</head>
<body>
<div class="app-layout">
  <?php include '../includes/sidebar.php'; ?>
  <div class="main-content">
    <div class="topbar">
      <div><div class="topbar-title">🍽️ Kelola Menu</div><div class="topbar-subtitle">Tambah, edit, hapus menu</div></div>
      <button class="btn btn-primary" onclick="openM('mTambah')">➕ Tambah Menu</button>
    </div>
    <div class="content-area">
      <?php if ($success): ?><div class="alert alert-success">✅ <?= $success ?></div><?php endif; ?>
      <?php if ($error):   ?><div class="alert alert-danger">⚠️ <?= $error ?></div><?php endif; ?>
      <div class="card">
        <div class="card-header">
          <h3>Daftar Menu (<?= count($menus) ?> item)</h3>
          <input type="text" id="srch" placeholder="🔍 Cari menu..." style="padding:8px 12px;border:1.5px solid #e5e7eb;border-radius:8px;font-size:13px;width:200px;font-family:inherit">
        </div>
        <div class="table-responsive">
          <table id="tblMenu">
            <thead><tr><th>#</th><th>Nama Menu</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
            <?php foreach ($menus as $i => $m): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><strong><?= htmlspecialchars($m['nama_menu']) ?></strong></td>
              <td><span class="badge badge-info"><?= $m['kategori'] ?></span></td>
              <td class="text-primary fw-700"><?= formatRupiah($m['harga']) ?></td>
              <td><?php if($m['stok']<=5): ?><span style="color:#ef4444;font-weight:700"><?= $m['stok'] ?> ⚠️</span><?php else: ?><?= $m['stok'] ?><?php endif; ?></td>
              <td>
                <?php if($m['tersedia']&&$m['stok']>0): ?><span class="badge badge-success">Tersedia</span>
                <?php elseif(!$m['tersedia']): ?><span class="badge badge-secondary">Nonaktif</span>
                <?php else: ?><span class="badge badge-danger">Habis</span><?php endif; ?>
              </td>
              <td style="display:flex;gap:6px">
                <button class="btn btn-secondary btn-sm" onclick='editM(<?= json_encode($m) ?>)'>✏️ Edit</button>
                <button class="btn btn-danger btn-sm" onclick="hapusM(<?= $m['id_menu'] ?>,'<?= addslashes($m['nama_menu']) ?>')">🗑️</button>
              </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Tambah -->
<div class="modal-overlay" id="mTambah">
  <div class="modal">
    <div class="modal-header"><h3>➕ Tambah Menu</h3><button class="modal-close" onclick="closeM('mTambah')">×</button></div>
    <form method="POST"><input type="hidden" name="action" value="tambah">
      <div class="modal-body">
        <div class="form-group"><label>Nama Menu</label><input type="text" name="nama_menu" placeholder="cth: Nasi Kucing Ayam" required></div>
        <div class="form-row">
          <div class="form-group"><label>Kategori</label><select name="kategori"><?php foreach($katList as $k): ?><option><?= $k ?></option><?php endforeach; ?></select></div>
          <div class="form-group"><label>Harga (Rp)</label><input type="number" name="harga" min="0" required></div>
        </div>
        <div class="form-group"><label>Stok Awal</label><input type="number" name="stok" min="0" required></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" onclick="closeM('mTambah')">Batal</button>
        <button type="submit" class="btn btn-primary">💾 Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Edit -->
<div class="modal-overlay" id="mEdit">
  <div class="modal">
    <div class="modal-header"><h3>✏️ Edit Menu</h3><button class="modal-close" onclick="closeM('mEdit')">×</button></div>
    <form method="POST"><input type="hidden" name="action" value="edit"><input type="hidden" name="id_menu" id="e_id">
      <div class="modal-body">
        <div class="form-group"><label>Nama Menu</label><input type="text" name="nama_menu" id="e_nama" required></div>
        <div class="form-row">
          <div class="form-group"><label>Kategori</label><select name="kategori" id="e_kat"><?php foreach($katList as $k): ?><option><?= $k ?></option><?php endforeach; ?></select></div>
          <div class="form-group"><label>Harga</label><input type="number" name="harga" id="e_harga" required></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Stok</label><input type="number" name="stok" id="e_stok" required></div>
          <div class="form-group"><label>Status</label><select name="tersedia" id="e_aktif"><option value="1">Tersedia</option><option value="0">Nonaktif</option></select></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" onclick="closeM('mEdit')">Batal</button>
        <button type="submit" class="btn btn-primary">💾 Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Hapus -->
<div class="modal-overlay" id="mHapus">
  <div class="modal">
    <form method="POST"><input type="hidden" name="action" value="hapus"><input type="hidden" name="id_menu" id="h_id">
      <div class="modal-header"><h3>🗑️ Hapus Menu</h3></div>
      <div class="modal-body">
        <p>Yakin hapus menu <strong id="h_nama"></strong>?</p>
        <p style="font-size:13px;color:#ef4444;margin-top:8px">⚠️ Data tidak dapat dikembalikan.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" onclick="closeM('mHapus')">Batal</button>
        <button type="submit" class="btn btn-danger">🗑️ Hapus</button>
      </div>
    </form>
  </div>
</div>

<script>
function openM(id)  { document.getElementById(id).classList.add('show'); }
function closeM(id) { document.getElementById(id).classList.remove('show'); }
function editM(m) {
  document.getElementById('e_id').value   = m.id_menu;
  document.getElementById('e_nama').value = m.nama_menu;
  document.getElementById('e_kat').value  = m.kategori;
  document.getElementById('e_harga').value= m.harga;
  document.getElementById('e_stok').value = m.stok;
  document.getElementById('e_aktif').value= m.tersedia;
  openM('mEdit');
}
function hapusM(id, nama) {
  document.getElementById('h_id').value  = id;
  document.getElementById('h_nama').textContent = nama;
  openM('mHapus');
}
document.getElementById('srch').addEventListener('input', function() {
  const q = this.value.toLowerCase();
  document.querySelectorAll('#tblMenu tbody tr').forEach(tr => {
    tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
});
document.querySelectorAll('.modal-overlay').forEach(o => {
  o.addEventListener('click', e => { if(e.target===o) o.classList.remove('show'); });
});
</script>
</body>
</html>
