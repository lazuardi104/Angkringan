<?php
session_start();
require_once '../includes/config.php';
requireAdmin();
$activePage = 'tempat';
$db = Database::getInstance();
$success = $error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action = $_POST['action']??'';
    if ($action==='tambah') {
        $nama = $db->escape($_POST['nama_tempat']);
        $kap  = (int)$_POST['kapasitas'];
        $db->query("INSERT INTO tempat (nama_tempat,kapasitas) VALUES ('$nama',$kap)");
        $success = 'Tempat berhasil ditambahkan!';
    } elseif ($action==='hapus') {
        $id = (int)$_POST['id_tempat'];
        $db->query("DELETE FROM tempat WHERE id_tempat=$id");
        $success = 'Tempat dihapus.';
    } elseif ($action==='reset') {
        $db->query("UPDATE tempat SET status='tersedia'");
        $success = 'Semua tempat direset ke tersedia.';
    }
}
$res = $db->query("SELECT * FROM tempat ORDER BY nama_tempat");
$tempats = [];
while ($r = $res->fetch_assoc()) $tempats[] = $r;
function tIcon($n){ if(str_contains($n,'Lesehan'))return'🛖'; if(str_contains($n,'Outdoor'))return'🌿'; if(str_contains($n,'Take'))return'🛍️'; return'🪑'; }
?>
<!DOCTYPE html><html lang="id">
<head><meta charset="UTF-8"><title>Kelola Tempat – <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css"></head>
<body>
<div class="app-layout">
  <?php include '../includes/sidebar.php'; ?>
  <div class="main-content">
    <div class="topbar">
      <div><div class="topbar-title">🪑 Kelola Tempat</div><div class="topbar-subtitle">Lesehan, meja, outdoor</div></div>
      <div style="display:flex;gap:10px">
        <form method="POST" style="display:inline"><input type="hidden" name="action" value="reset"><button type="submit" class="btn btn-secondary">🔄 Reset Semua</button></form>
        <button class="btn btn-primary" onclick="document.getElementById('mTambah').classList.add('show')">➕ Tambah</button>
      </div>
    </div>
    <div class="content-area">
      <?php if($success): ?><div class="alert alert-success">✅ <?= $success ?></div><?php endif; ?>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(155px,1fr));gap:14px">
        <?php foreach($tempats as $t):
          $cls = $t['status']==='terisi'?'badge-danger':($t['status']==='reserved'?'badge-warning':'badge-success');
        ?>
        <div class="card" style="padding:18px;text-align:center">
          <div style="font-size:34px;margin-bottom:8px"><?= tIcon($t['nama_tempat']) ?></div>
          <div style="font-weight:800;font-size:13.5px;margin-bottom:4px"><?= htmlspecialchars($t['nama_tempat']) ?></div>
          <div style="font-size:11.5px;color:#6b7280;margin-bottom:8px">Kapasitas: <?= $t['kapasitas'] ?> orang</div>
          <span class="badge <?= $cls ?>"><?= ucfirst($t['status']) ?></span>
          <div style="margin-top:12px">
            <form method="POST" onsubmit="return confirm('Hapus tempat ini?')">
              <input type="hidden" name="action" value="hapus">
              <input type="hidden" name="id_tempat" value="<?= $t['id_tempat'] ?>">
              <button type="submit" class="btn btn-danger btn-sm btn-full">🗑️ Hapus</button>
            </form>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
<div class="modal-overlay" id="mTambah">
  <div class="modal">
    <div class="modal-header"><h3>➕ Tambah Tempat</h3><button class="modal-close" onclick="document.getElementById('mTambah').classList.remove('show')">×</button></div>
    <form method="POST"><input type="hidden" name="action" value="tambah">
      <div class="modal-body">
        <div class="form-group"><label>Nama Tempat</label><input type="text" name="nama_tempat" placeholder="cth: Lesehan 4" required></div>
        <div class="form-group"><label>Kapasitas (orang)</label><input type="number" name="kapasitas" value="4" min="1" required></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" onclick="document.getElementById('mTambah').classList.remove('show')">Batal</button>
        <button type="submit" class="btn btn-primary">💾 Simpan</button>
      </div>
    </form>
  </div>
</div>
</body></html>
