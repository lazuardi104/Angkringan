<?php
session_start();
require_once '../includes/config.php';
requireAdmin();
$activePage = 'laporan';

$tanggal = '';
if (!empty($_GET['tanggal'])) {
    $d = DateTime::createFromFormat('Y-m-d', $_GET['tanggal']);
    if ($d && $d->format('Y-m-d') === $_GET['tanggal']) $tanggal = $_GET['tanggal'];
}
if (!$tanggal) $tanggal = date('Y-m-d');

$admin   = new Admin();
$orders  = $admin->lihatLaporan($tanggal);
$total   = array_sum(array_column($orders,'total'));
$tglShow = date('d F Y', strtotime($tanggal));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Laporan Penjualan – <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
</head>
<body>
<div class="app-layout">
  <?php include '../includes/sidebar.php'; ?>
  <div class="main-content">
    <div class="topbar">
      <div>
        <div class="topbar-title">📋 Laporan Penjualan</div>
        <div class="topbar-subtitle">Riwayat transaksi harian</div>
      </div>
      <button class="btn btn-success" onclick="window.print()">🖨️ Print</button>
    </div>
    <div class="content-area">

      <!-- FILTER -->
      <div class="card mb-20">
        <div class="card-body" style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap">
          <div class="form-group" style="margin:0;flex:1;min-width:180px">
            <label>Tanggal</label>
            <input type="date" id="filterTgl" value="<?= htmlspecialchars($tanggal) ?>" min="2020-01-01">
          </div>
          <button class="btn btn-primary" onclick="goFilter()">🔍 Tampilkan</button>
          <button class="btn btn-light" onclick="goDate('<?= date('Y-m-d') ?>')">📅 Hari Ini</button>
          <button class="btn btn-light" onclick="goDate('<?= date('Y-m-d',strtotime('-1 day')) ?>')">⬅️ Kemarin</button>
        </div>
      </div>

      <!-- STATS -->
      <div class="stats-grid" style="grid-template-columns:repeat(3,1fr)">
        <div class="stat-card red">
          <div class="stat-icon">💰</div>
          <div>
            <span class="stat-label">Total Pendapatan</span>
            <span class="stat-value sm"><?= formatRupiah($total) ?></span>
          </div>
        </div>
        <div class="stat-card green">
          <div class="stat-icon">🧾</div>
          <div>
            <span class="stat-label">Jumlah Transaksi</span>
            <span class="stat-value"><?= count($orders) ?></span>
          </div>
        </div>
        <div class="stat-card orange">
          <div class="stat-icon">📊</div>
          <div>
            <span class="stat-label">Rata-rata / Transaksi</span>
            <span class="stat-value sm"><?= count($orders) ? formatRupiah(intdiv($total,count($orders))) : 'Rp 0' ?></span>
          </div>
        </div>
      </div>

      <!-- TABLE -->
      <div class="card">
        <div class="card-header">
          <h3>📋 Detail Transaksi – <?= $tglShow ?></h3>
        </div>
        <div class="table-responsive">
          <?php if (empty($orders)): ?>
          <div class="empty-state"><span class="eicon">📭</span><p>Tidak ada transaksi pada tanggal ini</p></div>
          <?php else: ?>
          <table>
            <thead><tr><th>Kode Order</th><th>Kasir</th><th>Tempat</th><th>Total</th><th>Metode</th><th>Waktu</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($orders as $o): ?>
            <tr>
              <td><strong><?= htmlspecialchars($o['kode_order']) ?></strong></td>
              <td><?= htmlspecialchars($o['nama_lengkap']) ?></td>
              <td><?= htmlspecialchars($o['nama_tempat'] ?? 'Take Away') ?></td>
              <td><strong class="text-primary"><?= formatRupiah($o['total']) ?></strong></td>
              <td><?php $m=$o['metode_bayar']??'tunai'; ?>
                <span class="badge <?= $m==='tunai'?'badge-success':($m==='qris'?'badge-info':'badge-warning') ?>"><?= strtoupper($m) ?></span>
              </td>
              <td class="text-muted" style="font-size:12px"><?= date('H:i:s',strtotime($o['tanggal'])) ?></td>
              <td><button class="btn btn-outline btn-sm" onclick="lihatDetail(<?= $o['id_order'] ?>)">👁️ Detail</button></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Detail -->
<div class="modal-overlay" id="mdDetail">
  <div class="modal" style="max-width:560px">
    <div class="modal-header">
      <h3>🧾 Detail Order</h3>
      <button class="modal-close" onclick="document.getElementById('mdDetail').classList.remove('show')">×</button>
    </div>
    <div class="modal-body" id="detailContent"><div class="loading-spinner"></div></div>
  </div>
</div>

<script>
function goFilter() {
  const v = document.getElementById('filterTgl').value;
  if (!v) { alert('Pilih tanggal dulu!'); return; }
  location.href = 'laporan.php?tanggal=' + encodeURIComponent(v);
}
function goDate(d) {
  document.getElementById('filterTgl').value = d;
  location.href = 'laporan.php?tanggal=' + encodeURIComponent(d);
}
document.getElementById('filterTgl').addEventListener('keydown', e => { if (e.key==='Enter') goFilter(); });

async function lihatDetail(id) {
  document.getElementById('mdDetail').classList.add('show');
  document.getElementById('detailContent').innerHTML = '<div class="loading-spinner"></div>';
  const res  = await fetch('<?= BASE_URL ?>/kasir/api.php?action=detail_order&id=' + id);
  const data = await res.json();
  if (!data.success) return;
  const o = data.order, d = data.details;
  const rows = d.map(i => `<tr><td>${i.nama_menu}</td><td>${i.qty}</td><td>Rp ${parseInt(i.harga_satuan).toLocaleString('id-ID')}</td><td><strong>Rp ${parseInt(i.subtotal).toLocaleString('id-ID')}</strong></td></tr>`).join('');
  document.getElementById('detailContent').innerHTML = `
    <div style="margin-bottom:14px;font-size:13px;color:#6b7280"><strong style="color:#111827">${o.kode_order}</strong> &nbsp;|&nbsp; ${new Date(o.tanggal).toLocaleString('id-ID')} &nbsp;|&nbsp; Kasir: ${o.nama_lengkap}</div>
    <table><thead><tr><th>Menu</th><th>Qty</th><th>Harga</th><th>Subtotal</th></tr></thead><tbody>${rows}</tbody></table>
    <div style="display:flex;justify-content:space-between;padding:14px 0 0;font-size:18px;font-weight:800;border-top:2px solid #f3f4f6;margin-top:10px">
      <span>Total</span><span style="color:#e63946">Rp ${parseInt(o.total).toLocaleString('id-ID')}</span>
    </div>`;
}
document.getElementById('mdDetail').addEventListener('click', e => { if (e.target===e.currentTarget) e.currentTarget.classList.remove('show'); });
</script>
</body>
</html>
