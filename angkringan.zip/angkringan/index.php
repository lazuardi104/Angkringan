<?php
session_start();
require_once 'includes/config.php';
if (isLoggedIn()) {
    header('Location: ' . BASE_URL . (isAdmin() ? '/admin/dashboard.php' : '/kasir/dashboard.php'));
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $r = (new User())->login(trim($_POST['username'] ?? ''), $_POST['password'] ?? '');
    if ($r['success']) {
        $_SESSION['user_id'] = $r['user']['id_user'];
        $_SESSION['username']= $r['user']['username'];
        $_SESSION['nama']    = $r['user']['nama_lengkap'];
        $_SESSION['role']    = $r['user']['role'];
        header('Location: ' . BASE_URL . ($r['user']['role']==='admin' ? '/admin/dashboard.php' : '/kasir/dashboard.php'));
        exit;
    }
    $error = $r['message'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login – <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
</head>
<body>
<div class="login-wrapper">
  <div class="login-card">
    <div class="login-logo">
      <span class="icon">🍢</span>
      <h1><?= APP_NAME ?></h1>
      <p>Sistem Kasir Digital Angkringan</p>
    </div>
    <?php if ($error): ?>
    <div class="alert alert-danger">⚠️ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST" autocomplete="off">
      <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" placeholder="Masukkan username" required autofocus
               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="Masukkan password" required>
      </div>
      <button type="submit" class="btn btn-primary btn-full btn-lg" style="margin-top:8px">
        🔐 Masuk
      </button>
    </form>
    <div style="margin-top:20px;padding:13px 16px;background:#f9fafb;border-radius:8px;border:1px solid #e5e7eb;font-size:12px;color:#6b7280;line-height:1.8">
      
    </div>
  </div>
</div>
</body>
</html>
