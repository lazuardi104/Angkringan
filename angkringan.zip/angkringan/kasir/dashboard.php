<?php
session_start();
require_once '../includes/config.php';
requireLogin();
$activePage = 'kasir-dash';
$db  = Database::getInstance();
$uid = (int)$_SESSION['user_id'];

$r1 = $db->query("SELECT COUNT(*) as cnt, COALESCE(SUM(total),0) as tot FROM orders WHERE id_user=$uid AND DATE(tanggal)=CURDATE() AND status='selesai'");
$my  = $r1->fetch_assoc();
$r2  = $db->query("SELECT COUNT(*) as cnt FROM tempat WHERE status='tersedia'");
$tFree = (int)$r2->fetch_assoc()['cnt'];
$r3  = $db->query("SELECT COUNT(*) as cnt FROM menu WHERE tersedia=1 AND stok>0");
$mRdy = (int)$r3->fetch_assoc()['cnt'];
$r4  = $db->query("SELECT o.*, t.nama_tempat FROM orders o LEFT JOIN tempat t ON o.id_tempat=t.id_tempat WHERE o.id_user=$uid AND o.status='proses' ORDER BY o.tanggal DESC LIMIT 6");
$active = [];
while ($r = $r4->fetch_assoc()) $active[] = $r;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Beranda Kasir – <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
</head>
<body>
<div class="app-layout">
  <?php include '../includes/sidebar.php'; ?>
  <div class="main-content">
    <div class="topbar">
      <div>
        <div class="topbar-title">🏠 Beranda Kasir</div>
        <div class="topbar-subtitle">Selamat datang, <?= htmlspecialchars($_SESSION['nama']) ?>! — <?= date('l, d F Y') ?></div>
      </div>
      <a href="transaksi.php" class="btn btn-primary btn-lg">🛒 Transaksi Baru</a>
    </div>
    <div class="content-area">

      <div class="stats-grid">
        <div class="stat-card green">
          <div class="stat-icon">🧾</div>
          <div>
            <span class="stat-label">Transaksi Saya Hari Ini</span>
            <span class="stat-value"><?= $my['cnt'] ?></span>
          </div>
        </div>
        <div class="stat-card red">
          <div class="stat-icon">💰</div>
          <div>
            <span class="stat-label">Pendapatan Saya</span>
            <span class="stat-value sm"><?= formatRupiah((int)$my['tot']) ?></span>
          </div>
        </div>
        <div class="stat-card blue">
          <div class="stat-icon">🪑</div>
          <div>
            <span class="stat-label">Tempat Tersedia</span>
            <span class="stat-value"><?= $tFree ?></span>
          </div>
        </div>
        <div class="stat-card orange">
          <div class="stat-icon">🍽️</div>
          <div>
            <span class="stat-label">Menu Tersedia</span>
            <span class="stat-value"><?= $mRdy ?></span>
          </div>
        </div>
      </div>

      <!-- Quick Actions -->
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:14px;margin-bottom:22px">
        <a href="transaksi.php" style="text-decoration:none">
          <div class="card" style="padding:22px;text-align:center;cursor:pointer;transition:all .2s;border:1.5px solid transparent" onmouseover="this.style.borderColor='#e63946';this.style.transform='translateY(-2px)'" onmouseout="this.style.borderColor='';this.style.transform=''">
            <div style="font-size:38px;margin-bottom:10px">🛒</div>
            <div style="font-weight:800;color:#111827;font-size:14px">Transaksi Baru</div>
            <div style="font-size:12px;color:#6b7280;margin-top:4px">Buka kasir POS</div>
          </div>
        </a>
        <a href="riwayat.php" style="text-decoration:none">
          <div class="card" style="padding:22px;text-align:center;cursor:pointer;transition:all .2s;border:1.5px solid transparent" onmouseover="this.style.borderColor='#e63946';this.style.transform='translateY(-2px)'" onmouseout="this.style.borderColor='';this.style.transform=''">
            <div style="font-size:38px;margin-bottom:10px">📜</div>
            <div style="font-weight:800;color:#111827;font-size:14px">Riwayat</div>
            <div style="font-size:12px;color:#6b7280;margin-top:4px">Transaksi hari ini</div>
          </div>
        </a>
      </div>

      <?php if (!empty($active)): ?>
      <div class="card">
        <div class="card-header"><h3>⏳ Order Masih Proses (<?= count($active) ?>)</h3></div>
        <div class="table-responsive">
          <table>
            <thead><tr><th>Kode Order</th><th>Tempat</th><th>Total</th><th>Pukul</th><th>Aksi</th></tr></thead>
            <tbody>
            <?php foreach ($active as $o): ?>
            <tr>
              <td><strong><?= htmlspecialchars($o['kode_order']) ?></strong></td>
              <td><?= htmlspecialchars($o['nama_tempat'] ?? 'Take Away') ?></td>
              <td><strong class="text-primary"><?= formatRupiah($o['total']) ?></strong></td>
              <td class="text-muted" style="font-size:12px"><?= date('H:i',strtotime($o['tanggal'])) ?></td>
              <td><a href="transaksi.php?resume=<?= $o['id_order'] ?>" class="btn btn-secondary btn-sm">💳 Bayar</a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php endif; ?>

    </div>
  </div>
</div>
</body>
</html>
