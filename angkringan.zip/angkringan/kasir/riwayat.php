<?php
session_start();
require_once '../includes/config.php';
requireLogin();
$activePage = 'riwayat';
$db  = Database::getInstance();
$uid = (int)$_SESSION['user_id'];
$iam = isAdmin();

$where = $iam ? '' : "AND o.id_user = $uid";
$res = $db->query(
    "SELECT o.*, u.nama_lengkap, t.nama_tempat, p.metode_bayar, p.bayar_dengan, p.kembalian
     FROM orders o
     LEFT JOIN users u ON o.id_user=u.id_user
     LEFT JOIN tempat t ON o.id_tempat=t.id_tempat
     LEFT JOIN payments p ON o.id_order=p.id_order
     WHERE DATE(o.tanggal)=CURDATE() $where
     ORDER BY o.tanggal DESC"
);
$orders = [];
while ($r = $res->fetch_assoc()) $orders[] = $r;

$selesai = array_filter($orders, fn($o) => $o['status']==='selesai');
$proses  = array_filter($orders, fn($o) => $o['status']==='proses');
$totalPend = array_sum(array_column(array_values($selesai), 'total'));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Riwayat Hari Ini – <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
</head>
<body>
<div class="app-layout">
  <?php include '../includes/sidebar.php'; ?>
  <div class="main-content">
    <div class="topbar">
      <div>
        <div class="topbar-title">📜 Riwayat Hari Ini</div>
        <div class="topbar-subtitle"><?= date('l, d F Y') ?> – <?= count($orders) ?> transaksi</div>
      </div>
      <a href="transaksi.php" class="btn btn-primary">➕ Transaksi Baru</a>
    </div>
    <div class="content-area">

      <div class="stats-grid" style="grid-template-columns:repeat(3,1fr)">
        <div class="stat-card green">
          <div class="stat-icon">🧾</div>
          <div>
            <span class="stat-label">Total Transaksi</span>
            <span class="stat-value"><?= count($orders) ?></span>
          </div>
        </div>
        <div class="stat-card red">
          <div class="stat-icon">💰</div>
          <div>
            <span class="stat-label">Total Pendapatan</span>
            <span class="stat-value sm"><?= formatRupiah($totalPend) ?></span>
          </div>
        </div>
        <div class="stat-card orange">
          <div class="stat-icon">⏳</div>
          <div>
            <span class="stat-label">Masih Proses</span>
            <span class="stat-value"><?= count($proses) ?></span>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header"><h3>📋 Daftar Transaksi</h3></div>
        <div class="table-responsive">
          <?php if (empty($orders)): ?>
          <div class="empty-state">
            <span class="eicon">📭</span>
            <p>Belum ada transaksi hari ini</p>
            <a href="transaksi.php" class="btn btn-primary mt-16">🛒 Mulai Transaksi</a>
          </div>
          <?php else: ?>
          <table>
            <thead><tr><th>Kode</th><th>Kasir</th><th>Tempat</th><th>Total</th><th>Metode</th><th>Status</th><th>Waktu</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($orders as $o): ?>
            <tr>
              <td><strong><?= htmlspecialchars($o['kode_order']) ?></strong></td>
              <td style="font-size:12px"><?= htmlspecialchars($o['nama_lengkap']) ?></td>
              <td style="font-size:12px"><?= htmlspecialchars($o['nama_tempat'] ?? 'Take Away') ?></td>
              <td><strong class="text-primary"><?= formatRupiah($o['total']) ?></strong></td>
              <td>
                <?php if ($o['metode_bayar']): ?>
                <span class="badge <?= $o['metode_bayar']==='tunai'?'badge-success':($o['metode_bayar']==='qris'?'badge-info':'badge-warning') ?>"><?= strtoupper($o['metode_bayar']) ?></span>
                <?php else: ?>–<?php endif; ?>
              </td>
              <td><span class="badge <?= $o['status']==='selesai'?'badge-success':($o['status']==='proses'?'badge-warning':'badge-danger') ?>"><?= ucfirst($o['status']) ?></span></td>
              <td class="text-muted" style="font-size:12px"><?= date('H:i',strtotime($o['tanggal'])) ?></td>
              <td>
                <?php if ($o['status']==='proses'): ?>
                <a href="transaksi.php?resume=<?= $o['id_order'] ?>" class="btn btn-secondary btn-sm">💳 Bayar</a>
                <?php else: ?>
                <button class="btn btn-light btn-sm" onclick="lihatStruk(<?= $o['id_order'] ?>)">🧾 Struk</button>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal-overlay" id="mdStruk">
  <div class="modal" style="max-width:380px">
    <div class="modal-header">
      <h3>🧾 Struk Pembayaran</h3>
      <button class="modal-close" onclick="document.getElementById('mdStruk').classList.remove('show')">×</button>
    </div>
    <div class="modal-body" id="strukContent"><div class="loading-spinner"></div></div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="window.print()">🖨️ Cetak</button>
      <button class="btn btn-primary" onclick="document.getElementById('mdStruk').classList.remove('show')">Tutup</button>
    </div>
  </div>
</div>

<script>
async function lihatStruk(id) {
  document.getElementById('mdStruk').classList.add('show');
  document.getElementById('strukContent').innerHTML = '<div class="loading-spinner"></div>';
  const res  = await fetch('api.php?action=struk&id=' + id);
  const data = await res.json();
  if (!data.success) return;
  const o = data.order, d = data.details;
  const rows = d.map(i => `<div class="struk-row"><span>${i.nama_menu} x${i.qty}</span><span>Rp ${parseInt(i.subtotal).toLocaleString('id-ID')}</span></div>`).join('');
  document.getElementById('strukContent').innerHTML = `
    <div class="struk">
      <div class="struk-header">
        <div style="font-size:28px">🍢</div>
        <div class="struk-title"><?= APP_NAME ?></div>
        <div style="font-size:11px">Angkringan Jogja</div>
        <hr class="struk-divider">
        <div style="font-size:11.5px">${new Date(o.tanggal).toLocaleString('id-ID')}</div>
        <div style="font-size:11.5px">${o.kode_order}</div>
        <div style="font-size:11.5px">Kasir: ${o.nama_lengkap} | Tempat: ${o.nama_tempat||'Take Away'}</div>
      </div>
      <hr class="struk-divider">${rows}<hr class="struk-divider">
      <div class="struk-row"><strong>TOTAL</strong><strong>Rp ${parseInt(o.total).toLocaleString('id-ID')}</strong></div>
      <div class="struk-row"><span>Kembalian</span><span>Rp ${parseInt(o.kembalian||0).toLocaleString('id-ID')}</span></div>
      <div class="struk-footer" style="margin-top:10px">Terima kasih sudah makan di sini! 🙏</div>
    </div>`;
}
document.getElementById('mdStruk').addEventListener('click', e => { if (e.target===e.currentTarget) e.currentTarget.classList.remove('show'); });
</script>
</body>
</html>
