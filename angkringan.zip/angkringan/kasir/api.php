<?php
session_start();
require_once '../includes/config.php';
requireLogin();
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

if ($method === 'GET') {
    if ($action === 'struk' || $action === 'detail_order') {
        $id = (int)($_GET['id'] ?? 0);
        $data = (new Cashier())->printReceipt($id);
        echo json_encode(['success' => true, 'order' => $data['order'], 'details' => $data['details']]);
        exit;
    }
} elseif ($method === 'POST') {
    $body   = json_decode(file_get_contents('php://input'), true) ?? [];
    $action = $body['action'] ?? '';
    if ($action === 'add_order') {
        echo json_encode((new Cashier())->addOrder(
            (int)$_SESSION['user_id'],
            (int)($body['id_tempat'] ?? 0),
            $body['items'] ?? []
        ));
        exit;
    } elseif ($action === 'bayar') {
        echo json_encode((new Cashier())->processPayment(
            (int)$body['id_order'],
            $body['metode'] ?? 'tunai',
            (int)($body['bayar_dengan'] ?? 0)
        ));
        exit;
    }
}
echo json_encode(['success' => false, 'message' => 'Invalid request']);
