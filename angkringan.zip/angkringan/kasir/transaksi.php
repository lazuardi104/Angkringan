<?php
session_start();
require_once '../includes/config.php';
requireLogin();
$activePage = 'transaksi';
$menuObj = new Menu();
$tempatObj = new Tempat();
$allMenu = $menuObj->getAll();
$allTempat = $tempatObj->getAll();
$kategoriList = $menuObj->getKategori();

// Emoji mapping
function menuEmoji($nama, $kat) {
    $n = strtolower($nama);
    if (str_contains($n,'nasi')) return '🍚';
    if (str_contains($n,'sate')) return '🍢';
    if (str_contains($n,'gorengan')||str_contains($n,'tempe')||str_contains($n,'tahu')) return '🧆';
    if (str_contains($n,'pisang')) return '🍌';
    if (str_contains($n,'kopi')) return '☕';
    if (str_contains($n,'teh')) return '🧋';
    if (str_contains($n,'jeruk')) return '🍊';
    if (str_contains($n,'jahe')||str_contains($n,'wedang')) return '🫚';
    if (str_contains($n,'susu')) return '🥛';
    if (str_contains($n,'air')) return '💧';
    if ($kat === 'Minuman') return '🥤';
    return '🍽️';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Transaksi - <?= APP_NAME ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
</head>
<body>
<div class="app-layout">
  <?php include '../includes/sidebar.php'; ?>
  <div class="main-content">
    <div class="topbar">
      <div>
        <div class="topbar-title">🛒 Kasir POS</div>
        <div class="topbar-subtitle" id="waktuSekarang"></div>
      </div>
      <div style="display:flex;gap:10px;align-items:center">
        <div style="font-size:13px;color:#7f8c8d">Tempat: <strong id="tempatLabel">Belum dipilih</strong></div>
        <button class="btn btn-light btn-sm" onclick="openModal('modalTempat')">🪑 Pilih Tempat</button>
        <button class="btn btn-danger btn-sm" onclick="clearOrder()">🗑️ Reset</button>
      </div>
    </div>

    <div class="content-area" style="padding-top:16px">
      <div class="pos-layout">

        <!-- LEFT: Menu -->
        <div class="menu-panel">
          <!-- Kategori Filter -->
          <div class="kategori-tabs">
            <button class="kategori-tab active" onclick="filterKategori('semua', this)">Semua</button>
            <?php foreach ($kategoriList as $k): ?>
            <button class="kategori-tab" onclick="filterKategori('<?= htmlspecialchars($k) ?>', this)"><?= $k ?></button>
            <?php endforeach; ?>
          </div>
          <!-- Search -->
          <input type="text" id="searchMenuPOS" placeholder="🔍 Cari menu..." style="width:100%;padding:10px 14px;border:2px solid #eee;border-radius:8px;font-size:14px;margin-bottom:14px">
          <!-- Menu Grid -->
          <div class="menu-grid" id="menuGrid">
            <?php foreach ($allMenu as $m):
              $emoji = menuEmoji($m['nama_menu'], $m['kategori']);
              $habis = $m['stok'] <= 0;
            ?>
            <div class="menu-item-card <?= $habis ? 'out-of-stock' : '' ?>"
                 data-id="<?= $m['id_menu'] ?>"
                 data-nama="<?= htmlspecialchars($m['nama_menu']) ?>"
                 data-harga="<?= $m['harga'] ?>"
                 data-stok="<?= $m['stok'] ?>"
                 data-kat="<?= htmlspecialchars($m['kategori']) ?>"
                 onclick="<?= $habis ? '' : 'addToCart(this)' ?>">
              <span class="emoji"><?= $emoji ?></span>
              <div class="nama"><?= htmlspecialchars($m['nama_menu']) ?></div>
              <div class="harga"><?= formatRupiah($m['harga']) ?></div>
              <div class="stok"><?= $habis ? '❌ Habis' : "Stok: {$m['stok']}" ?></div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- RIGHT: Order -->
        <div class="order-panel">
          <div class="order-card">
            <div class="order-header">
              <div style="font-size:14px;font-weight:700;margin-bottom:4px">🧾 Pesanan</div>
              <div style="font-size:12px;opacity:.8" id="orderKode">Belum ada order</div>
            </div>

            <div class="order-items" id="orderItems">
              <div class="empty-state" id="emptyOrder">
                <span class="icon" style="font-size:36px">🛒</span>
                <p style="font-size:13px">Pilih menu di sebelah kiri</p>
              </div>
            </div>

            <div class="order-footer">
              <div class="order-total-row">
                <span>Total</span>
                <span id="totalDisplay" class="text-primary">Rp 0</span>
              </div>
              <button class="btn btn-primary btn-full btn-lg" onclick="prosesCheckout()" id="btnCheckout" disabled>
                💳 Proses Pembayaran
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>

<!-- Modal Pilih Tempat -->
<div class="modal-overlay" id="modalTempat">
  <div class="modal" style="max-width:600px">
    <div class="modal-header">
      <h3>🪑 Pilih Tempat</h3>
      <button class="modal-close" onclick="closeModal('modalTempat')">×</button>
    </div>
    <div class="modal-body">
      <div class="tempat-grid">
        <div class="tempat-card <?= '' ?>" onclick="pilihTempat(0, 'Take Away')" id="tempat-0">
          <span class="tempat-icon">🛍️</span>
          <div class="tempat-name">Take Away</div>
          <div class="tempat-status">Bawa pulang</div>
        </div>
        <?php foreach ($allTempat as $t):
          $disabled = $t['status'] === 'terisi' ? 'disabled' : '';
          $icon = str_contains($t['nama_tempat'], 'Lesehan') ? '🛖' : (str_contains($t['nama_tempat'], 'Outdoor') ? '🌿' : '🪑');
        ?>
        <div class="tempat-card <?= $disabled ?>" onclick="<?= $disabled ? '' : "pilihTempat({$t['id_tempat']}, '{$t['nama_tempat']}')" ?>" id="tempat-<?= $t['id_tempat'] ?>">
          <span class="tempat-icon"><?= $icon ?></span>
          <div class="tempat-name"><?= htmlspecialchars($t['nama_tempat']) ?></div>
          <div class="tempat-status"><?= ucfirst($t['status']) ?> · <?= $t['kapasitas'] ?> org</div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<!-- Modal Pembayaran -->
<div class="modal-overlay" id="modalBayar">
  <div class="modal" style="max-width:480px">
    <div class="modal-header">
      <h3>💳 Proses Pembayaran</h3>
      <button class="modal-close" onclick="closeModal('modalBayar')">×</button>
    </div>
    <div class="modal-body">
      <div style="background:#f8f9fa;border-radius:8px;padding:16px;margin-bottom:16px">
        <div style="display:flex;justify-content:space-between;font-size:13px;color:#7f8c8d;margin-bottom:4px">
          <span>Tempat</span><span id="bayarTempat">-</span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:20px;font-weight:700;color:#c0392b">
          <span>Total Bayar</span><span id="bayarTotal">Rp 0</span>
        </div>
      </div>
      <div class="form-group">
        <label>Metode Pembayaran</label>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
          <label class="metode-btn active" onclick="setMetode('tunai',this)">💵<br><span>Tunai</span></label>
          <label class="metode-btn" onclick="setMetode('qris',this)">📱<br><span>QRIS</span></label>
          <label class="metode-btn" onclick="setMetode('transfer',this)">🏦<br><span>Transfer</span></label>
        </div>
      </div>
      <div class="form-group" id="inputBayarGroup">
        <label>Bayar Dengan (Rp)</label>
        <input type="number" id="inputBayar" placeholder="Masukkan nominal" oninput="hitungKembalian()">
      </div>
      <div id="kembalianBox" style="background:#e8f8ee;border-radius:8px;padding:14px;display:none">
        <div style="display:flex;justify-content:space-between;font-size:16px;font-weight:700;color:#27ae60">
          <span>Kembalian</span><span id="kembalianDisplay">Rp 0</span>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:12px" id="nominalBtns">
        <button class="btn btn-light btn-sm" onclick="setNominal(5000)">5k</button>
        <button class="btn btn-light btn-sm" onclick="setNominal(10000)">10k</button>
        <button class="btn btn-light btn-sm" onclick="setNominal(20000)">20k</button>
        <button class="btn btn-light btn-sm" onclick="setNominal(50000)">50k</button>
        <button class="btn btn-light btn-sm" onclick="setNominal(100000)">100k</button>
        <button class="btn btn-light btn-sm" onclick="setNominal(totalAmount)">Pas</button>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-light" onclick="closeModal('modalBayar')">Batal</button>
      <button class="btn btn-success btn-lg" onclick="konfirmasiBayar()" id="btnBayarKonfirm">✅ Konfirmasi Bayar</button>
    </div>
  </div>
</div>

<!-- Modal Struk -->
<div class="modal-overlay" id="modalStruk">
  <div class="modal" style="max-width:400px">
    <div class="modal-header">
      <h3>🧾 Struk Pembayaran</h3>
      <button class="modal-close" onclick="selesaiTransaksi()">×</button>
    </div>
    <div class="modal-body" id="strukContent"></div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="cetakStruk()">🖨️ Cetak</button>
      <button class="btn btn-primary" onclick="selesaiTransaksi()">✅ Selesai</button>
    </div>
  </div>
</div>

<style>
.metode-btn {
  border: 2px solid #eee; border-radius: 8px; padding: 12px 8px;
  text-align: center; cursor: pointer; font-size: 22px; transition: all .2s;
  display: block;
}
.metode-btn span { display: block; font-size: 12px; font-weight: 600; color: #7f8c8d; margin-top: 4px; }
.metode-btn.active { border-color: #c0392b; background: #fdecea; }
.metode-btn.active span { color: #c0392b; }
</style>

<script>
let cart = {};
let selectedTempat = { id: 0, nama: 'Take Away' };
let totalAmount = 0;
let metodeBayar = 'tunai';
let currentOrderId = null;

// Clock
function updateClock() {
  document.getElementById('waktuSekarang').textContent = new Date().toLocaleString('id-ID', {weekday:'long',day:'numeric',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'});
}
setInterval(updateClock, 1000); updateClock();

// Filter Kategori
function filterKategori(kat, btn) {
  document.querySelectorAll('.kategori-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.menu-item-card').forEach(card => {
    card.style.display = (kat === 'semua' || card.dataset.kat === kat) ? '' : 'none';
  });
}

// Search
document.getElementById('searchMenuPOS').addEventListener('input', function() {
  const q = this.value.toLowerCase();
  document.querySelectorAll('.menu-item-card').forEach(card => {
    card.style.display = card.dataset.nama.toLowerCase().includes(q) ? '' : 'none';
  });
});

// Add to cart
function addToCart(el) {
  const id = el.dataset.id, nama = el.dataset.nama, harga = parseInt(el.dataset.harga), stok = parseInt(el.dataset.stok);
  if (cart[id]) {
    if (cart[id].qty >= stok) { alert('Stok tidak cukup!'); return; }
    cart[id].qty++;
  } else {
    cart[id] = { id, nama, harga, qty: 1, stok };
  }
  renderCart(); el.style.animation='none'; el.offsetHeight; el.style.animation='bounce .3s';
}

function changeQty(id, delta) {
  if (!cart[id]) return;
  cart[id].qty += delta;
  if (cart[id].qty <= 0) delete cart[id];
  renderCart();
}

function renderCart() {
  const container = document.getElementById('orderItems');
  const ids = Object.keys(cart);

  // Hapus semua item lama (kecuali #emptyOrder)
  container.querySelectorAll('.order-item').forEach(el => el.remove());

  if (ids.length === 0) {
    container.querySelector('#emptyOrder').style.display = 'block';
    totalAmount = 0;
    document.getElementById('totalDisplay').textContent = 'Rp 0';
    document.getElementById('btnCheckout').disabled = true;
    return;
  }

  container.querySelector('#emptyOrder').style.display = 'none';
  let total = 0;

  ids.forEach(id => {
    const item = cart[id];
    const sub = item.harga * item.qty;
    total += sub;

    const div = document.createElement('div');
    div.className = 'order-item';
    div.dataset.cartId = id;
    div.innerHTML = `
      <div class="item-name">${item.nama}</div>
      <div class="qty-ctrl">
        <button class="qty-btn" onclick="changeQty('${id}', -1)">−</button>
        <span class="qty-num">${item.qty}</span>
        <button class="qty-btn" onclick="changeQty('${id}', 1)">+</button>
      </div>
      <div class="item-sub">Rp ${sub.toLocaleString('id-ID')}</div>`;
    container.appendChild(div);
  });

  totalAmount = total;
  document.getElementById('totalDisplay').textContent = 'Rp ' + total.toLocaleString('id-ID');
  document.getElementById('btnCheckout').disabled = false;
}

// Tempat
function pilihTempat(id, nama) {
  selectedTempat = { id, nama };
  document.getElementById('tempatLabel').textContent = nama;
  document.querySelectorAll('.tempat-card').forEach(c => c.classList.remove('selected'));
  const el = document.getElementById('tempat-' + id);
  if (el) el.classList.add('selected');
  closeModal('modalTempat');
}

// Checkout
async function prosesCheckout() {
  if (Object.keys(cart).length === 0) { alert('Pilih menu dulu!'); return; }
  // Save order to DB
  const items = Object.values(cart).map(i => ({ id_menu: i.id, harga: i.harga, qty: i.qty }));
  const res = await fetch('<?= BASE_URL ?>/kasir/api.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'add_order', id_tempat: selectedTempat.id, items })
  });
  const data = await res.json();
  if (!data.success) { alert(data.message || 'Gagal membuat order'); return; }
  currentOrderId = data.id_order;
  document.getElementById('orderKode').textContent = data.kode_order;
  document.getElementById('bayarTotal').textContent = 'Rp ' + data.total.toLocaleString('id-ID');
  document.getElementById('bayarTempat').textContent = selectedTempat.nama;
  document.getElementById('inputBayar').value = '';
  document.getElementById('kembalianBox').style.display = 'none';
  openModal('modalBayar');
}

// Bayar
function setMetode(m, el) {
  metodeBayar = m;
  document.querySelectorAll('.metode-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('inputBayarGroup').style.display = m === 'tunai' ? '' : 'none';
  document.getElementById('nominalBtns').style.display = m === 'tunai' ? '' : 'none';
  document.getElementById('kembalianBox').style.display = 'none';
}

function setNominal(n) {
  document.getElementById('inputBayar').value = n;
  hitungKembalian();
}

function hitungKembalian() {
  const bayar = parseInt(document.getElementById('inputBayar').value) || 0;
  const kembalian = bayar - totalAmount;
  if (kembalian >= 0) {
    document.getElementById('kembalianBox').style.display = '';
    document.getElementById('kembalianDisplay').textContent = 'Rp ' + kembalian.toLocaleString('id-ID');
  } else {
    document.getElementById('kembalianBox').style.display = 'none';
  }
}

async function konfirmasiBayar() {
  const bayar = metodeBayar === 'tunai' ? parseInt(document.getElementById('inputBayar').value) || 0 : totalAmount;
  if (metodeBayar === 'tunai' && bayar < totalAmount) { alert('Uang tidak cukup!'); return; }
  const btn = document.getElementById('btnBayarKonfirm');
  btn.disabled = true; btn.textContent = '⏳ Memproses...';
  const res = await fetch('<?= BASE_URL ?>/kasir/api.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'bayar', id_order: currentOrderId, metode: metodeBayar, bayar_dengan: bayar })
  });
  const data = await res.json();
  btn.disabled = false; btn.textContent = '✅ Konfirmasi Bayar';
  if (data.success) {
    closeModal('modalBayar');
    await tampilStruk(currentOrderId, data);
  } else {
    alert(data.message || 'Gagal proses pembayaran');
  }
}

async function tampilStruk(idOrder, payData) {
  const res = await fetch('<?= BASE_URL ?>/kasir/api.php?action=struk&id=' + idOrder);
  const data = await res.json();
  if (!data.success) return;
  const o = data.order, d = data.details;
  const tgl = new Date(o.tanggal).toLocaleString('id-ID');
  let rows = d.map(i => `
    <div class="struk-row"><span>${i.nama_menu} x${i.qty}</span><span>Rp ${parseInt(i.subtotal).toLocaleString('id-ID')}</span></div>`).join('');
  document.getElementById('strukContent').innerHTML = `
    <div class="struk">
      <div class="struk-header">
        <div style="font-size:24px">🍢</div>
        <div class="struk-title"><?= APP_NAME ?></div>
        <div style="font-size:11px">Angkringan Jogja</div>
        <hr class="struk-divider">
        <div style="font-size:12px">${tgl}</div>
        <div style="font-size:12px">${o.kode_order}</div>
        <div style="font-size:12px">Kasir: ${o.nama_lengkap}</div>
        <div style="font-size:12px">Tempat: ${o.nama_tempat || 'Take Away'}</div>
      </div>
      <hr class="struk-divider">
      ${rows}
      <hr class="struk-divider">
      <div class="struk-row"><strong>TOTAL</strong><strong>Rp ${parseInt(o.total).toLocaleString('id-ID')}</strong></div>
      <div class="struk-row"><span>Bayar (${o.metode_bayar||'tunai'})</span><span>Rp ${parseInt(o.bayar_dengan||o.total).toLocaleString('id-ID')}</span></div>
      <div class="struk-row"><span>Kembalian</span><span>Rp ${parseInt(o.kembalian||0).toLocaleString('id-ID')}</span></div>
      <hr class="struk-divider">
      <div class="struk-footer">
        <div>Terima kasih sudah makan di sini! 🙏</div>
        <div>Selamat makan~</div>
      </div>
    </div>`;
  openModal('modalStruk');
}

function cetakStruk() { window.print(); }

function selesaiTransaksi() {
  cart = {};
  currentOrderId = null;
  selectedTempat = { id: 0, nama: 'Take Away' };
  document.getElementById('tempatLabel').textContent = 'Belum dipilih';
  document.getElementById('orderKode').textContent = 'Belum ada order';
  renderCart();
  closeModal('modalStruk');
  document.querySelectorAll('.tempat-card').forEach(c => c.classList.remove('selected'));
}

function clearOrder() {
  if (Object.keys(cart).length === 0) return;
  if (confirm('Reset semua pesanan?')) { cart = {}; renderCart(); }
}

function openModal(id) { document.getElementById(id).classList.add('show'); }
function closeModal(id) { document.getElementById(id).classList.remove('show'); }
document.querySelectorAll('.modal-overlay').forEach(o => {
  o.addEventListener('click', e => { if (e.target === o) o.classList.remove('show'); });
});
</script>
</body>
</html>
