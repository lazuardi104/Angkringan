-- =============================================
-- DATABASE: Web Kasir Angkringan
-- Import ke phpMyAdmin
-- =============================================

-- Gunakan database yang sudah dibuat di InfinityFree: if0_41880512_angkringan_db
-- CREATE DATABASE sudah dilakukan via panel InfinityFree
-- Langsung pilih database:
CREATE DATABASE IF NOT EXISTS `if0_41880512_angkringan_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `if0_41880512_angkringan_db`;

-- =============================================
-- Tabel: users
-- =============================================
CREATE TABLE IF NOT EXISTS `users` (
  `id_user` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `nama_lengkap` VARCHAR(150) NOT NULL,
  `role` ENUM('admin','kasir') NOT NULL DEFAULT 'kasir',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================
-- Tabel: menu
-- =============================================
CREATE TABLE IF NOT EXISTS `menu` (
  `id_menu` INT(11) NOT NULL AUTO_INCREMENT,
  `nama_menu` VARCHAR(150) NOT NULL,
  `kategori` VARCHAR(50) NOT NULL DEFAULT 'Makanan',
  `harga` INT(11) NOT NULL DEFAULT 0,
  `stok` INT(11) NOT NULL DEFAULT 0,
  `tersedia` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================
-- Tabel: tempat (Table / Lesehan)
-- =============================================
CREATE TABLE IF NOT EXISTS `tempat` (
  `id_tempat` INT(11) NOT NULL AUTO_INCREMENT,
  `nama_tempat` VARCHAR(100) NOT NULL,
  `kapasitas` INT(11) NOT NULL DEFAULT 4,
  `status` ENUM('tersedia','terisi','reserved') NOT NULL DEFAULT 'tersedia',
  PRIMARY KEY (`id_tempat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================
-- Tabel: orders
-- =============================================
CREATE TABLE IF NOT EXISTS `orders` (
  `id_order` INT(11) NOT NULL AUTO_INCREMENT,
  `kode_order` VARCHAR(20) NOT NULL,
  `id_user` INT(11) NOT NULL,
  `id_tempat` INT(11) DEFAULT NULL,
  `tanggal` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total` INT(11) NOT NULL DEFAULT 0,
  `status` ENUM('proses','selesai','batal') NOT NULL DEFAULT 'proses',
  PRIMARY KEY (`id_order`),
  UNIQUE KEY `kode_order` (`kode_order`),
  KEY `fk_order_user` (`id_user`),
  KEY `fk_order_tempat` (`id_tempat`),
  CONSTRAINT `fk_order_user` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`),
  CONSTRAINT `fk_order_tempat` FOREIGN KEY (`id_tempat`) REFERENCES `tempat` (`id_tempat`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================
-- Tabel: order_detail
-- =============================================
CREATE TABLE IF NOT EXISTS `order_detail` (
  `id_detail` INT(11) NOT NULL AUTO_INCREMENT,
  `id_order` INT(11) NOT NULL,
  `id_menu` INT(11) NOT NULL,
  `qty` INT(11) NOT NULL DEFAULT 1,
  `harga_satuan` INT(11) NOT NULL,
  `subtotal` INT(11) NOT NULL,
  PRIMARY KEY (`id_detail`),
  KEY `fk_detail_order` (`id_order`),
  KEY `fk_detail_menu` (`id_menu`),
  CONSTRAINT `fk_detail_order` FOREIGN KEY (`id_order`) REFERENCES `orders` (`id_order`) ON DELETE CASCADE,
  CONSTRAINT `fk_detail_menu` FOREIGN KEY (`id_menu`) REFERENCES `menu` (`id_menu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================
-- Tabel: payments
-- =============================================
CREATE TABLE IF NOT EXISTS `payments` (
  `id_payment` INT(11) NOT NULL AUTO_INCREMENT,
  `id_order` INT(11) NOT NULL,
  `metode_bayar` ENUM('tunai','qris','transfer') NOT NULL DEFAULT 'tunai',
  `total_bayar` INT(11) NOT NULL,
  `kembalian` INT(11) NOT NULL DEFAULT 0,
  `bayar_dengan` INT(11) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_payment`),
  KEY `fk_payment_order` (`id_order`),
  CONSTRAINT `fk_payment_order` FOREIGN KEY (`id_order`) REFERENCES `orders` (`id_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================
-- Data Awal: Users
-- Password: admin123 (hash bcrypt)
-- =============================================
INSERT INTO `users` (`username`, `password`, `nama_lengkap`, `role`) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin'),
('kasir1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Budi Santoso', 'kasir'),
('kasir2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Siti Rahayu', 'kasir');

-- =============================================
-- Data Awal: Menu Angkringan
-- =============================================
INSERT INTO `menu` (`nama_menu`, `kategori`, `harga`, `stok`) VALUES
('Nasi Kucing Ayam', 'Makanan', 3000, 50),
('Nasi Kucing Ikan', 'Makanan', 3000, 50),
('Nasi Kucing Tempe', 'Makanan', 2500, 50),
('Sate Usus', 'Sate', 2000, 100),
('Sate Ati Ampela', 'Sate', 2500, 80),
('Sate Telur Puyuh', 'Sate', 1500, 100),
('Sate Bakso', 'Sate', 3000, 80),
('Gorengan Tempe', 'Gorengan', 1000, 100),
('Gorengan Tahu', 'Gorengan', 1000, 100),
('Gorengan Pisang', 'Gorengan', 1500, 60),
('Es Teh Manis', 'Minuman', 3000, 999),
('Es Jeruk', 'Minuman', 4000, 999),
('Kopi Jos', 'Minuman', 5000, 999),
('Wedang Jahe', 'Minuman', 4000, 999),
('Susu Jahe', 'Minuman', 5000, 999),
('Air Mineral', 'Minuman', 3000, 999);

-- =============================================
-- Data Awal: Tempat
-- =============================================
INSERT INTO `tempat` (`nama_tempat`, `kapasitas`, `status`) VALUES
('Lesehan 1', 6, 'tersedia'),
('Lesehan 2', 6, 'tersedia'),
('Lesehan 3', 4, 'tersedia'),
('Meja Kayu 1', 4, 'tersedia'),
('Meja Kayu 2', 4, 'tersedia'),
('Outdoor 1', 8, 'tersedia'),
('Outdoor 2', 8, 'tersedia'),
('Take Away', 1, 'tersedia');
