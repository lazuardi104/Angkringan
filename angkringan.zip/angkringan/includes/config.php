<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'angkringan_db');

define('APP_NAME', 'Angkringan Mas Bro');
define('BASE_URL', '/angkringan'); // sesuaikan folder project

// ============================================================
// CLASS: Database (Singleton)
// ============================================================
class Database {
    private static $instance = null;
    private $connection;

    private function __construct() {
        mysqli_report(MYSQLI_REPORT_OFF);
        $this->connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($this->connection->connect_error) {
            die('<div style="font-family:sans-serif;padding:40px;color:#c0392b"><h2>⚠️ Koneksi Database Gagal</h2><p>'.$this->connection->connect_error.'</p></div>');
        }
        $this->connection->set_charset('utf8mb4');
    }

    public static function getInstance() {
        if (self::$instance === null) self::$instance = new Database();
        return self::$instance;
    }
    public function getConnection() { return $this->connection; }
    public function query($sql) { return $this->connection->query($sql); }
    public function prepare($sql) { return $this->connection->prepare($sql); }
    public function escape($v) { return $this->connection->real_escape_string($v); }
    public function lastInsertId() { return $this->connection->insert_id; }
}

// ============================================================
// CLASS: User (Base)
// ============================================================
class User {
    protected $db;

    public function __construct() { $this->db = Database::getInstance(); }

    public function login(string $username, string $password): array {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        if ($user && password_verify($password, $user['password'])) {
            return ['success' => true, 'user' => $user];
        }
        return ['success' => false, 'message' => 'Username atau password salah'];
    }

    public function getById(int $id): ?array {
        $stmt = $this->db->prepare("SELECT id_user, username, nama_lengkap, role, created_at FROM users WHERE id_user = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    public function getAllUsers(): array {
        $result = $this->db->query("SELECT id_user, username, nama_lengkap, role, created_at FROM users ORDER BY role, nama_lengkap");
        $rows = [];
        while ($r = $result->fetch_assoc()) $rows[] = $r;
        return $rows;
    }
}

// ============================================================
// CLASS: Admin (extends User)
// ============================================================
class Admin extends User {
    public function tambahMenu(string $nama, string $kategori, int $harga, int $stok): array {
        $stmt = $this->db->prepare("INSERT INTO menu (nama_menu, kategori, harga, stok) VALUES (?,?,?,?)");
        $stmt->bind_param("ssii", $nama, $kategori, $harga, $stok);
        return $stmt->execute()
            ? ['success' => true, 'id' => $this->db->lastInsertId()]
            : ['success' => false, 'message' => 'Gagal tambah menu'];
    }

    public function editMenu(int $id, string $nama, string $kat, int $harga, int $stok, int $tersedia): array {
        $stmt = $this->db->prepare("UPDATE menu SET nama_menu=?,kategori=?,harga=?,stok=?,tersedia=? WHERE id_menu=?");
        $stmt->bind_param("ssiiii", $nama, $kat, $harga, $stok, $tersedia, $id);
        return $stmt->execute() ? ['success' => true] : ['success' => false, 'message' => 'Gagal update'];
    }

    public function hapusMenu(int $id): array {
        $stmt = $this->db->prepare("DELETE FROM menu WHERE id_menu=?");
        $stmt->bind_param("i", $id);
        return $stmt->execute() ? ['success' => true] : ['success' => false];
    }

    public function lihatLaporan(string $tanggal = null): array {
        $tgl = $tanggal ?: date('Y-m-d');
        $stmt = $this->db->prepare(
            "SELECT o.*, u.nama_lengkap, t.nama_tempat, p.metode_bayar, p.bayar_dengan, p.kembalian
             FROM orders o
             LEFT JOIN users u ON o.id_user = u.id_user
             LEFT JOIN tempat t ON o.id_tempat = t.id_tempat
             LEFT JOIN payments p ON o.id_order = p.id_order
             WHERE DATE(o.tanggal) = ? AND o.status = 'selesai'
             ORDER BY o.tanggal DESC"
        );
        $stmt->bind_param("s", $tgl);
        $stmt->execute();
        $rows = [];
        $res = $stmt->get_result();
        while ($r = $res->fetch_assoc()) $rows[] = $r;
        return $rows;
    }

    public function getDashboardStats(): array {
        $conn = $this->db->getConnection();
        $s = [];
        $r = $conn->query("SELECT COALESCE(SUM(total),0) as v FROM orders WHERE DATE(tanggal)=CURDATE() AND status='selesai'");
        $s['today'] = (int)$r->fetch_assoc()['v'];
        $r = $conn->query("SELECT COALESCE(SUM(total),0) as v FROM orders WHERE MONTH(tanggal)=MONTH(CURDATE()) AND YEAR(tanggal)=YEAR(CURDATE()) AND status='selesai'");
        $s['month'] = (int)$r->fetch_assoc()['v'];
        $r = $conn->query("SELECT COUNT(*) as v FROM orders WHERE DATE(tanggal)=CURDATE() AND status='selesai'");
        $s['txToday'] = (int)$r->fetch_assoc()['v'];
        $r = $conn->query("SELECT COUNT(*) as v FROM menu WHERE tersedia=1 AND stok>0");
        $s['menuAktif'] = (int)$r->fetch_assoc()['v'];
        $r = $conn->query("SELECT COUNT(*) as v FROM tempat WHERE status='terisi'");
        $s['tempatTerisi'] = (int)$r->fetch_assoc()['v'];

        // Grafik 7 hari — ambil semua lalu map di PHP agar tidak ada gap
        $r = $conn->query("SELECT DATE(tanggal) as tgl, COALESCE(SUM(total),0) as total FROM orders WHERE tanggal >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) AND status='selesai' GROUP BY DATE(tanggal)");
        $dbRows = [];
        while ($row = $r->fetch_assoc()) $dbRows[$row['tgl']] = (int)$row['total'];
        $chart = [];
        for ($i = 6; $i >= 0; $i--) {
            $d = date('Y-m-d', strtotime("-$i day"));
            $chart[] = ['tgl' => $d, 'total' => $dbRows[$d] ?? 0];
        }
        $s['chart'] = $chart;

        // Menu terlaris 30 hari
        $r = $conn->query("SELECT m.nama_menu, SUM(od.qty) as terjual FROM order_detail od JOIN menu m ON od.id_menu=m.id_menu JOIN orders o ON od.id_order=o.id_order WHERE o.status='selesai' AND DATE(o.tanggal)>=DATE_SUB(CURDATE(),INTERVAL 30 DAY) GROUP BY od.id_menu ORDER BY terjual DESC LIMIT 5");
        $s['terlaris'] = [];
        while ($row = $r->fetch_assoc()) $s['terlaris'][] = $row;

        return $s;
    }

    public function tambahUser(string $username, string $password, string $nama, string $role): array {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->db->prepare("INSERT INTO users (username, password, nama_lengkap, role) VALUES (?,?,?,?)");
        $stmt->bind_param("ssss", $username, $hash, $nama, $role);
        return $stmt->execute() ? ['success' => true] : ['success' => false, 'message' => 'Username sudah dipakai'];
    }

    public function hapusUser(int $id): void {
        $stmt = $this->db->prepare("DELETE FROM users WHERE id_user=? AND role != 'admin'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
}

// ============================================================
// CLASS: Cashier (extends User)
// ============================================================
class Cashier extends User {
    public function addOrder(int $idUser, int $idTempat, array $items): array {
        $conn = $this->db->getConnection();
        $conn->begin_transaction();
        try {
            $kode  = 'ORD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -5));
            $total = array_sum(array_map(fn($i) => $i['harga'] * $i['qty'], $items));
            $tp    = $idTempat > 0 ? $idTempat : null;
            $stmt  = $this->db->prepare("INSERT INTO orders (kode_order,id_user,id_tempat,total,status) VALUES (?,?,?,?,'proses')");
            $stmt->bind_param("siii", $kode, $idUser, $tp, $total);
            $stmt->execute();
            $idOrder = $this->db->lastInsertId();

            foreach ($items as $item) {
                $sub = $item['harga'] * $item['qty'];
                $s2  = $this->db->prepare("INSERT INTO order_detail (id_order,id_menu,qty,harga_satuan,subtotal) VALUES (?,?,?,?,?)");
                $s2->bind_param("iiiii", $idOrder, $item['id_menu'], $item['qty'], $item['harga'], $sub);
                $s2->execute();
                $this->updateStock($item['id_menu'], $item['qty']);
            }

            if ($idTempat > 0) {
                $s3 = $this->db->prepare("UPDATE tempat SET status='terisi' WHERE id_tempat=?");
                $s3->bind_param("i", $idTempat);
                $s3->execute();
            }
            $conn->commit();
            return ['success' => true, 'id_order' => $idOrder, 'kode_order' => $kode, 'total' => $total];
        } catch (Exception $e) {
            $conn->rollback();
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    public function updateStock(int $idMenu, int $qty): void {
        $stmt = $this->db->prepare("UPDATE menu SET stok = stok - ? WHERE id_menu = ? AND stok >= ?");
        $stmt->bind_param("iii", $qty, $idMenu, $qty);
        $stmt->execute();
    }

    public function printReceipt(int $idOrder): array {
        $stmt = $this->db->prepare(
            "SELECT o.*, u.nama_lengkap, t.nama_tempat, p.metode_bayar, p.bayar_dengan, p.kembalian
             FROM orders o
             LEFT JOIN users u ON o.id_user=u.id_user
             LEFT JOIN tempat t ON o.id_tempat=t.id_tempat
             LEFT JOIN payments p ON o.id_order=p.id_order
             WHERE o.id_order=?"
        );
        $stmt->bind_param("i", $idOrder);
        $stmt->execute();
        $order = $stmt->get_result()->fetch_assoc();

        $s2 = $this->db->prepare("SELECT od.*, m.nama_menu FROM order_detail od JOIN menu m ON od.id_menu=m.id_menu WHERE od.id_order=?");
        $s2->bind_param("i", $idOrder);
        $s2->execute();
        $details = [];
        $res = $s2->get_result();
        while ($r = $res->fetch_assoc()) $details[] = $r;
        return ['order' => $order, 'details' => $details];
    }

    public function processPayment(int $idOrder, string $metode, int $bayarDengan): array {
        $stmt = $this->db->prepare("SELECT total FROM orders WHERE id_order=?");
        $stmt->bind_param("i", $idOrder);
        $stmt->execute();
        $order = $stmt->get_result()->fetch_assoc();
        if (!$order) return ['success' => false, 'message' => 'Order tidak ditemukan'];
        $total     = (int)$order['total'];
        $kembalian = $bayarDengan - $total;
        if ($kembalian < 0 && $metode === 'tunai') return ['success' => false, 'message' => 'Uang tidak cukup'];

        $s2 = $this->db->prepare("INSERT INTO payments (id_order,metode_bayar,total_bayar,bayar_dengan,kembalian) VALUES (?,?,?,?,?)");
        $s2->bind_param("isiii", $idOrder, $metode, $total, $bayarDengan, $kembalian);
        $s2->execute();

        $s3 = $this->db->prepare("UPDATE orders SET status='selesai' WHERE id_order=?");
        $s3->bind_param("i", $idOrder);
        $s3->execute();

        // Bebaskan tempat
        $s4 = $this->db->prepare("UPDATE tempat SET status='tersedia' WHERE id_tempat=(SELECT id_tempat FROM orders WHERE id_order=? LIMIT 1)");
        $s4->bind_param("i", $idOrder);
        $s4->execute();

        return ['success' => true, 'kembalian' => $kembalian, 'total' => $total];
    }
}

// ============================================================
// CLASS: Menu
// ============================================================
class Menu {
    private $db;
    public function __construct() { $this->db = Database::getInstance(); }

    public function getAll(string $kategori = ''): array {
        if ($kategori) {
            $stmt = $this->db->prepare("SELECT * FROM menu WHERE kategori=? AND tersedia=1 ORDER BY nama_menu");
            $stmt->bind_param("s", $kategori);
            $stmt->execute();
            $res = $stmt->get_result();
        } else {
            $res = $this->db->query("SELECT * FROM menu WHERE tersedia=1 ORDER BY kategori, nama_menu");
        }
        $rows = [];
        while ($r = $res->fetch_assoc()) $rows[] = $r;
        return $rows;
    }

    public function getKategori(): array {
        $res = $this->db->query("SELECT DISTINCT kategori FROM menu WHERE tersedia=1 ORDER BY kategori");
        $k = [];
        while ($r = $res->fetch_assoc()) $k[] = $r['kategori'];
        return $k;
    }
}

// ============================================================
// CLASS: Tempat
// ============================================================
class Tempat {
    private $db;
    public function __construct() { $this->db = Database::getInstance(); }

    public function getAll(): array {
        $res = $this->db->query("SELECT * FROM tempat ORDER BY nama_tempat");
        $rows = [];
        while ($r = $res->fetch_assoc()) $rows[] = $r;
        return $rows;
    }
}

// ============================================================
// HELPERS
// ============================================================
function isLoggedIn(): bool  { return !empty($_SESSION['user_id']); }
function isAdmin(): bool     { return ($_SESSION['role'] ?? '') === 'admin'; }

function requireLogin(): void {
    if (!isLoggedIn()) { header('Location: ' . BASE_URL . '/index.php'); exit; }
}
function requireAdmin(): void {
    requireLogin();
    if (!isAdmin()) { header('Location: ' . BASE_URL . '/kasir/dashboard.php'); exit; }
}

function formatRupiah(int $n): string {
    return 'Rp ' . number_format($n, 0, ',', '.');
}

function menuEmoji(string $nama, string $kat): string {
    $n = strtolower($nama);
    if (str_contains($n,'nasi'))   return '🍚';
    if (str_contains($n,'sate'))   return '🍢';
    if (str_contains($n,'pisang')) return '🍌';
    if (str_contains($n,'tahu') || str_contains($n,'gorengan')) return '🧆';
    if (str_contains($n,'tempe'))  return '🟤';
    if (str_contains($n,'kopi'))   return '☕';
    if (str_contains($n,'teh'))    return '🧋';
    if (str_contains($n,'jeruk'))  return '🍊';
    if (str_contains($n,'jahe') || str_contains($n,'wedang')) return '🫗';
    if (str_contains($n,'susu'))   return '🥛';
    if (str_contains($n,'air'))    return '💧';
    if ($kat === 'Minuman')        return '🥤';
    return '🍽️';
}
