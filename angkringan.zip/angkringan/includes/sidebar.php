<?php
// includes/sidebar.php — dipanggil setelah $activePage diset
$_role  = $_SESSION['role']  ?? 'kasir';
$_nama  = $_SESSION['nama']  ?? 'User';
$_uname = $_SESSION['username'] ?? '';
$_av    = strtoupper(substr($_nama, 0, 1));
?>
<div class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-logo">🍢</div>
    <div class="brand-text">
      <span class="brand-name"><?= APP_NAME ?></span>
      <span class="brand-sub">Kasir Digital v2.0</span>
    </div>
  </div>

  <nav class="sidebar-menu">
    <?php if ($_role === 'admin'): ?>
    <div class="menu-section-title">Admin Panel</div>
    <a href="<?= BASE_URL ?>/admin/dashboard.php" class="<?= $activePage==='dashboard'?'active':'' ?>">
      <span class="nav-icon">📊</span> Dashboard
    </a>
    <a href="<?= BASE_URL ?>/admin/menu.php" class="<?= $activePage==='menu'?'active':'' ?>">
      <span class="nav-icon">🍽️</span> Kelola Menu
    </a>
    <a href="<?= BASE_URL ?>/admin/tempat.php" class="<?= $activePage==='tempat'?'active':'' ?>">
      <span class="nav-icon">🪑</span> Kelola Tempat
    </a>
    <a href="<?= BASE_URL ?>/admin/laporan.php" class="<?= $activePage==='laporan'?'active':'' ?>">
      <span class="nav-icon">📋</span> Laporan Penjualan
    </a>
    <a href="<?= BASE_URL ?>/admin/users.php" class="<?= $activePage==='users'?'active':'' ?>">
      <span class="nav-icon">👥</span> Kelola User
    </a>
    <div class="menu-section-title" style="margin-top:6px">Kasir</div>
    <?php endif; ?>
    <a href="<?= BASE_URL ?>/kasir/dashboard.php" class="<?= $activePage==='kasir-dash'?'active':'' ?>">
      <span class="nav-icon">🏠</span> Beranda Kasir
    </a>
    <a href="<?= BASE_URL ?>/kasir/transaksi.php" class="<?= $activePage==='transaksi'?'active':'' ?>">
      <span class="nav-icon">🛒</span> Transaksi Baru
    </a>
    <a href="<?= BASE_URL ?>/kasir/riwayat.php" class="<?= $activePage==='riwayat'?'active':'' ?>">
      <span class="nav-icon">📜</span> Riwayat Hari Ini
    </a>
  </nav>

  <div class="sidebar-footer">
    <div class="user-card">
      <div class="user-avatar"><?= $_av ?></div>
      <div>
        <div class="user-name"><?= htmlspecialchars($_nama) ?></div>
        <div class="user-role"><?= ucfirst($_role) ?></div>
      </div>
    </div>
    <a href="<?= BASE_URL ?>/logout.php" class="btn btn-danger btn-sm btn-full">🚪 Logout</a>
  </div>
</div>
